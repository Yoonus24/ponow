import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:purchaseorders2/providers/permission_provider.dart';
import 'package:purchaseorders2/providers/template_provider.dart';
import 'package:purchaseorders2/widgets/po page/po_model.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/po/po.dart';
import '../../providers/po/po_provider.dart';
import '../../screens/create_po_page.dart';
import '../../notifier/purchasenotifier.dart';

class POWidget extends StatefulWidget {
  final PO po;
  final bool isSelected;
  final VoidCallback? onStatusChanged;

  const POWidget({
    super.key,
    required this.po,
    required this.isSelected,
    this.onStatusChanged,
  });

  @override
  State<POWidget> createState() => _POWidgetState();
}

class _POWidgetState extends State<POWidget> {
  bool _isHeaderScrolling = false;
  bool _isBodyScrolling = false;

  late ScrollController _headerHorizontal;
  late ScrollController _bodyHorizontal;

  @override
  void initState() {
    super.initState();
    _headerHorizontal = ScrollController();
    _bodyHorizontal = ScrollController();

    _bodyHorizontal.addListener(() {
      if (_isBodyScrolling) return;
      _isHeaderScrolling = true;
      if (_headerHorizontal.hasClients) {
        _headerHorizontal.jumpTo(_bodyHorizontal.position.pixels);
      }
      _isHeaderScrolling = false;
    });

    _headerHorizontal.addListener(() {
      if (_isHeaderScrolling) return;
      _isBodyScrolling = true;
      if (_bodyHorizontal.hasClients) {
        _bodyHorizontal.jumpTo(_headerHorizontal.position.pixels);
      }
      _isBodyScrolling = false;
    });
  }

  @override
  void dispose() {
    _headerHorizontal.dispose();
    _bodyHorizontal.dispose();
    super.dispose();
  }

  Color _getStatusColor(String? status) {
    return Colors.blueAccent;
  }

  Color _getHeaderColor(String? orderDate) {
    return Colors.blueAccent;
  }

  String _getFormattedDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) return 'N/A';
    try {
      DateTime date;
      try {
        date = DateTime.parse(dateString);
      } catch (_) {
        final clean = dateString.split('.')[0].split('+')[0];
        date = DateTime.parse(clean);
      }
      return DateFormat('dd-MM-yyyy').format(date);
    } catch (_) {
      return dateString;
    }
  }

  String _getDisplayStatus(PO po) {
    switch (po.poStatus) {
      case 'Pending':
        return 'PENDING';

      case 'Pending for Approve':
        return 'PENDING FOR APPROVAL';

      case 'CreditLimit for Approve':
        return 'CREDIT LIMIT FOR APPROVAL';

      case 'Approved':
        return 'APPROVED';

      case 'Rejected':
        return 'REJECTED';

      case 'PartiallyReceived':
        return 'PARTIALLY RECEIVED';

      default:
        return po.poStatus?.toUpperCase() ?? 'PENDING';
    }
  }

  @override
  Widget build(BuildContext context) {
    final permission = context.watch<PermissionProvider>();

    bool canEditPO = permission.hasPermission(
      "yenerp",
      "purchaseorders_pending", // or approved based on your module
      "edit",
    );
    return Consumer<POProvider>(
      builder: (context, poProvider, child) {
        final updatedPO = poProvider.poList.firstWhere(
          (p) => p.purchaseOrderId == widget.po.purchaseOrderId,
          orElse: () => widget.po,
        );

        final double itemsTotal = updatedPO.items.fold(
          0.0,
          (sum, item) => sum + (item.pendingFinalPrice ?? 0),
        );

        final double freightAmount = updatedPO.totalFreightAmount ?? 0;
        final double freightTax = updatedPO.totalFreightTaxAmount ?? 0;
        final double roundOff = updatedPO.roundOffAdjustment ?? 0;

        final double cardTotal =
            itemsTotal + freightAmount + freightTax + roundOff;
        return Container(
          margin: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: widget.isSelected
                  ? [const Color(0xFFE6F0FA), const Color(0xFFD6EAF8)]
                  : [const Color(0xFFF8F9FA), const Color(0xFFECEFF1)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
            boxShadow: const [
              BoxShadow(
                color: Color.fromARGB(255, 74, 122, 227),
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
            border: widget.isSelected
                ? Border.all(color: const Color(0xFF87CEEB), width: 2)
                : Border.all(color: Colors.transparent),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _getHeaderColor(updatedPO.orderDate),
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(10),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          // ✅ FIX: Added Flexible
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: _getStatusColor(updatedPO.poStatus),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              _getDisplayStatus(updatedPO),
                              style: GoogleFonts.quicksand(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 20,
                          ),
                          onPressed: () {
                            if (!canEditPO) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text("No permission to edit PO"),
                                  backgroundColor: Colors.red,
                                ),
                              );
                              return;
                            }

                            _editPO(context, updatedPO);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          // ✅ FIX: Added Flexible
                          child: Text(
                            "PO No: ${updatedPO.randomId}",
                            style: GoogleFonts.quicksand(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Text(
                          _getFormattedDate(updatedPO.orderDate),
                          style: GoogleFonts.quicksand(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      "Vendor: ${updatedPO.vendorName}",
                      style: GoogleFonts.quicksand(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 3),

                    Text(
                      "Total: ${cardTotal.toStringAsFixed(2)}",
                      style: GoogleFonts.quicksand(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 200, // or 220 (adjust if needed)
                child: _buildPOItemsTable(updatedPO),
              ),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton(
                      onPressed: () => _openApproveModal(context, updatedPO),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        foregroundColor: Colors.white,
                      ),
                      child: const Text("Approve"),
                    ),
                    const SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () => _openRejectModal(context, updatedPO),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 191, 74, 74),
                        foregroundColor: Colors.white,
                      ),
                      child: const Text("Reject"),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPOItemsTable(PO updatedPO) {
    final items = updatedPO.items
        .where((item) => (item.pendingTotalQuantity ?? 0) > 0)
        .toList();
    const double rowHeight = 48;
    const double headerHeight = 48;
    const double itemNameWidth = 120;

    final List<double> widths = [60, 60, 60, 70, 90, 90, 90, 90, 100, 100];
    final rightTotalWidth = widths.fold<double>(0, (sum, w) => sum + w);

    return Column(
      children: [
        Row(
          children: [
            Container(
              width: itemNameWidth,
              height: headerHeight,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.all(8),
              color: Colors.grey[300],
              child: const Text(
                "Item Name",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                controller: _headerHorizontal,
                scrollDirection: Axis.horizontal,
                child: SizedBox(
                  width: rightTotalWidth,
                  height: headerHeight,
                  child: Row(
                    children: [
                      _headerCell("Qty", widths[0]),
                      _headerCell("Pkt Count", widths[1]),
                      _headerCell("UOM", widths[2]),
                      _headerCell("Total", widths[3]),
                      _headerCell("Existing Price", widths[4]),
                      _headerCell("New Price", widths[5]),
                      _headerCell("Discount", widths[6]),
                      _headerCell("Tax", widths[7]),
                      _headerCell("Total Price", widths[8]),
                      _headerCell("Final Price", widths[9]),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        Expanded(
          child: SingleChildScrollView(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: items.map((item) {
                    return Container(
                      width: itemNameWidth,
                      height: rowHeight,
                      alignment: Alignment.centerLeft,
                      padding: const EdgeInsets.all(8),
                      color: Colors.grey[200],
                      child: Text(
                        item.itemName ?? "",
                        maxLines: 2,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    controller: _bodyHorizontal,
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: rightTotalWidth,
                      child: Column(
                        children: items.map((item) {
                          return SizedBox(
                            height: rowHeight,
                            child: Row(
                              children: [
                                _dataCell("${item.pendingQuantity}", widths[0]),
                                _dataCell("${item.pendingCount}", widths[1]),
                                _dataCell(item.uom ?? "", widths[2]),
                                _dataCell(
                                  "${item.pendingTotalQuantity}",
                                  widths[3],
                                ),
                                _dataCell(
                                  item.existingPrice?.toStringAsFixed(2) ??
                                      "0.00",
                                  widths[4],
                                ),
                                _dataCell(
                                  item.newPrice?.toStringAsFixed(2) ?? "0.00",
                                  widths[5],
                                ),
                                _dataCell(
                                  item.pendingDiscountAmount?.toStringAsFixed(
                                        2,
                                      ) ??
                                      "0.00",
                                  widths[6],
                                ),
                                _dataCell(
                                  item.pendingTaxAmount?.toStringAsFixed(2) ??
                                      "0.00",
                                  widths[7],
                                ),
                                _dataCell(
                                  item.pendingTotalPrice?.toStringAsFixed(2) ??
                                      "0.00",
                                  widths[8],
                                ),
                                _dataCell(
                                  item.pendingFinalPrice?.toStringAsFixed(2) ??
                                      "0.00",
                                  widths[9],
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _headerCell(String text, double width) {
    return Container(
      width: width,
      height: 48,
      alignment: Alignment.center,
      color: Colors.grey[300],
      child: Text(
        text,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 12,
          color: Colors.black,
        ),
      ),
    );
  }

  Widget _dataCell(String text, double width) {
    return Container(
      width: width,
      height: 48,
      alignment: Alignment.center,
      color: Colors.grey[200],
      child: Text(
        text,
        style: const TextStyle(fontSize: 12, color: Colors.black),
      ),
    );
  }

  void _openApproveModal(BuildContext context, PO updatedPO) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => POModal(
        po: updatedPO,
        key: UniqueKey(),
        showApproveButton: true,
        showRejectButton: false,
      ),
    );
  }

  void _openRejectModal(BuildContext context, PO updatedPO) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => POModal(
        po: updatedPO,
        key: UniqueKey(),
        showApproveButton: false,
        showRejectButton: true,
      ),
    );
  }

  void _editPO(BuildContext context, PO po) async {
    final notifier = Provider.of<PurchaseOrderNotifier>(context, listen: false);

    final poProvider = Provider.of<POProvider>(context, listen: false);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    final fullPO = await poProvider.fetchPOById(po.purchaseOrderId);

    if (!context.mounted) return;

    Navigator.of(context).pop();

    if (fullPO == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Failed to load PO details")),
      );

      return;
    }

    notifier.setEditingPO(fullPO);

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => PurchaseOrderDialog(
        key: UniqueKey(),
        editingPO: fullPO,
        templateProvider: context.read<TemplateProvider>(),
      ),
    );
  }
}
