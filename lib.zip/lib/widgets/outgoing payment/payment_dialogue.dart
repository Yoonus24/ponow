import 'package:flutter/material.dart';
import 'package:purchaseorders2/providers/payment_dialog_provider.dart';
import 'package:provider/provider.dart';
import '../../utils/calculator_utils.dart';

class PaymentDialog extends StatelessWidget {
  final double totalPayableAmount;
  final bool isBulkPayment;
  final bool lockFullPayment;
  final Function(
    String paymentType,
    double amount,
    String paymentMode,
    String paymentMethod,
    Map<String, dynamic> transactionDetails,
  )
  onPaymentConfirmed;

  const PaymentDialog({
    super.key,
    required this.totalPayableAmount,
    required this.onPaymentConfirmed,
    this.isBulkPayment = false,
    this.lockFullPayment = false,
  });

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => PaymentDialogProvider(
        totalPayableAmount: totalPayableAmount,
        isBulkPayment: isBulkPayment,
      ),
      child: Builder(
        builder: (context) {
          return Consumer<PaymentDialogProvider>(
            builder: (context, provider, _) {
              // Show full screen loader when submitting
              if (provider.isSubmitting) {
                return Dialog(
                  backgroundColor: Colors.transparent,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const CircularProgressIndicator(
                          strokeWidth: 3,
                          color: Colors.blueAccent,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Processing Payment...',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey[700],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }

              return AlertDialog(
                backgroundColor: Colors.white,
                title: Text(
                  isBulkPayment ? 'Confirm Bulk Payment' : 'Confirm Payment',
                ),
                content: SingleChildScrollView(
                  child: Form(
                    key: provider.formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Total Payable: ${totalPayableAmount.toStringAsFixed(2)}',
                        ),
                        if (isBulkPayment) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Number of Payments: ${provider.paymentCount}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                        const SizedBox(height: 16),
                        _buildPaymentTypeDropdown(provider),
                        const SizedBox(height: 16),
                        _buildAmountField(provider, context),
                        const SizedBox(height: 16),
                        _buildPaymentModeDropdown(provider),

                        if (provider.selectedPaymentMode == 'Cash') ...[
                          // const SizedBox(height: 16),
                          // _buildCashTypeDropdown(provider),
                        ],

                        if (provider.selectedPaymentMode == 'Bank') ...[
                          const SizedBox(height: 16),
                          ..._buildBankFields(context, provider),
                        ],
                      ],
                    ),
                  ),
                ),
                actions: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: _buildCancelButton(context, provider)),
                      const SizedBox(width: 10),
                      Expanded(child: _buildConfirmButton(context, provider)),
                    ],
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildPaymentTypeDropdown(PaymentDialogProvider provider) {
    return DropdownButtonFormField<String>(
      initialValue: provider.selectedPaymentType,
      decoration: InputDecoration(
        labelText: 'Payment Type',
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey[400]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.black54),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.blueAccent, width: 2.0),
        ),
        filled: true,
        fillColor: Colors.white,
        labelStyle: const TextStyle(color: Colors.black87),
        floatingLabelStyle: const TextStyle(color: Colors.blueAccent),
      ),
      dropdownColor: Colors.white,
      items: const [
        DropdownMenuItem(value: 'full', child: Text('Full Payment')),
        DropdownMenuItem(value: 'partial', child: Text('Partial Payment')),
      ],
      onChanged: provider.isSubmitting
          ? null
          : (value) {
              provider.setPaymentType(value!);
              if (value == 'full') {
                provider.amountController.text = totalPayableAmount
                    .toStringAsFixed(2);
              }
            },
      validator: (value) =>
          value == null ? 'Please select a payment type' : null,
    );
  }

  Widget _buildAmountField(
    PaymentDialogProvider provider,
    BuildContext context,
  ) {
    final bool isFullPayment = provider.selectedPaymentType == 'full';
    return GestureDetector(
      onTap: isFullPayment || provider.isSubmitting
          ? null
          : () {
              showNumericCalculator(
                context: context,
                controller: provider.amountController,
                varianceName: 'Enter Amount',
                onValueSelected: () {
                  final double entered =
                      double.tryParse(provider.amountController.text) ?? 0.0;

                  if (provider.selectedPaymentType == 'partial' &&
                      entered > totalPayableAmount) {
                    provider.amountController.text = totalPayableAmount
                        .toStringAsFixed(2);

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Amount cannot exceed '
                          '${totalPayableAmount.toStringAsFixed(2)}',
                        ),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
                fieldType: '',
              );
            },
      child: AbsorbPointer(
        absorbing: provider.isSubmitting || isFullPayment,
        child: TextFormField(
          controller: provider.amountController,
          enabled: !isFullPayment && !provider.isSubmitting,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'Amount',
            hintText: isFullPayment ? 'Full payment amount' : 'Enter amount',
            filled: true,
            fillColor: isFullPayment ? Colors.grey.shade100 : Colors.white,
            suffixIcon: isFullPayment
                ? const Icon(Icons.lock, size: 18)
                : const Icon(Icons.calculate, size: 18),
            border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey[400]!),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: isFullPayment ? Colors.grey : Colors.black54,
              ),
            ),
            focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Colors.blueAccent, width: 2),
            ),
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter an amount';
            }

            final double? amount = double.tryParse(value);
            if (amount == null || amount <= 0) {
              return 'Please enter a valid amount';
            }

            if (provider.selectedPaymentType == 'partial' &&
                amount > totalPayableAmount) {
              return 'Amount cannot exceed '
                  '${totalPayableAmount.toStringAsFixed(2)}';
            }

            return null;
          },
        ),
      ),
    );
  }

  Widget _buildPaymentModeDropdown(PaymentDialogProvider provider) {
    return DropdownButtonFormField<String>(
      initialValue: provider.selectedPaymentMode,
      decoration: InputDecoration(
        labelText: 'Payment Mode',
        border: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey[400]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.black54),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.blueAccent, width: 2.0),
        ),
        filled: true,
        fillColor: Colors.white,
        labelStyle: const TextStyle(color: Colors.black87),
        floatingLabelStyle: const TextStyle(color: Colors.black87),
      ),
      dropdownColor: Colors.white,
      items: const [
        DropdownMenuItem(value: 'Cash', child: Text('Cash')),
        DropdownMenuItem(value: 'Bank', child: Text('Bank')),
      ],
      onChanged: provider.isSubmitting
          ? null
          : (value) {
              provider.setPaymentMode(value!);
            },
      validator: (value) =>
          value == null ? 'Please select a payment mode' : null,
    );
  }

  List<Widget> _buildBankFields(
    BuildContext context,
    PaymentDialogProvider provider,
  ) {
    return [
      provider.isLoadingBanks
          ? const Center(child: CircularProgressIndicator())
          : provider.bankError != null
          ? Column(
              children: [
                Text(
                  provider.bankError!,
                  style: const TextStyle(color: Colors.red),
                ),
                TextButton(
                  onPressed: provider.isSubmitting
                      ? null
                      : () {
                          provider.fetchBanks();
                        },
                  child: const Text('Retry'),
                ),
              ],
            )
          : Autocomplete<String>(
              optionsBuilder: (TextEditingValue textEditingValue) {
                if (textEditingValue.text.isEmpty) {
                  return provider.banks.map((b) => b.bankName);
                }
                return provider.banks
                    .map((b) => b.bankName)
                    .where(
                      (name) => name.toLowerCase().contains(
                        textEditingValue.text.toLowerCase(),
                      ),
                    );
              },
              onSelected: provider.isSubmitting
                  ? null
                  : (String selection) {
                      provider.setBankName(selection);
                    },
              fieldViewBuilder:
                  (
                    BuildContext context,
                    TextEditingController controller,
                    FocusNode focusNode,
                    VoidCallback onFieldSubmitted,
                  ) {
                    return TextFormField(
                      controller: controller,
                      focusNode: focusNode,
                      enabled: !provider.isSubmitting,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        labelText: 'Bank Name',
                        suffixIcon: const Icon(Icons.search),
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey),
                        ),
                        enabledBorder: const OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.black54),
                        ),
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.blueAccent,
                            width: 2,
                          ),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (value) => value == null || value.isEmpty
                          ? 'Please select a bank'
                          : null,
                    );
                  },
              optionsViewBuilder:
                  (
                    BuildContext context,
                    AutocompleteOnSelected<String> onSelected,
                    Iterable<String> options,
                  ) {
                    return Align(
                      alignment: Alignment.topLeft,
                      child: Material(
                        elevation: 4,
                        color: Colors.white,
                        child: SizedBox(
                          height: 200,
                          width: MediaQuery.of(context).size.width * 0.8,
                          child: ListView.builder(
                            padding: EdgeInsets.zero,
                            itemCount: options.length,
                            itemBuilder: (context, index) {
                              final option = options.elementAt(index);
                              return ListTile(
                                tileColor: Colors.white,
                                title: Text(
                                  option,
                                  style: const TextStyle(color: Colors.black),
                                ),
                                onTap: provider.isSubmitting
                                    ? null
                                    : () => onSelected(option),
                              );
                            },
                          ),
                        ),
                      ),
                    );
                  },
            ),

      const SizedBox(height: 16),

      DropdownButtonFormField<String>(
        initialValue: provider.selectedBankPaymentMethod,
        decoration: InputDecoration(
          labelText: 'Bank Payment Method',
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey[400]!),
          ),
          enabledBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.black54),
          ),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blueAccent, width: 2),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
        items: const [
          DropdownMenuItem(value: 'neft', child: Text('NEFT')),
          DropdownMenuItem(value: 'rtgs', child: Text('RTGS')),
          DropdownMenuItem(value: 'imps', child: Text('IMPS')),
          DropdownMenuItem(value: 'upi', child: Text('UPI')),
        ],
        onChanged: provider.isSubmitting
            ? null
            : (value) {
                provider.setBankPaymentMethod(value!);
              },
        validator: (value) =>
            value == null ? 'Please select a payment method' : null,
      ),

      const SizedBox(height: 16),

      provider.selectedBankPaymentMethod == 'upi'
          ? TextFormField(
              controller: provider.transactionController,
              enabled: !provider.isSubmitting,
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                labelText: 'UPI ID / Reference',
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey[400]!),
                ),
                enabledBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black54),
                ),
                focusedBorder: const OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blueAccent, width: 2),
                ),
                filled: true,
                fillColor: Colors.white,
              ),
              validator: (value) => value == null || value.isEmpty
                  ? 'Please enter UPI reference'
                  : null,
            )
          : GestureDetector(
              onTap: provider.isSubmitting
                  ? null
                  : () {
                      showNumericCalculator(
                        context: context,
                        controller: provider.transactionController,
                        varianceName: 'Enter Reference Number',
                        onValueSelected: () {},
                        fieldType: 'number',
                      );
                    },
              child: AbsorbPointer(
                absorbing: true,
                child: TextFormField(
                  controller: provider.transactionController,
                  enabled: !provider.isSubmitting,
                  decoration: InputDecoration(
                    labelText: provider.getTransactionLabel(),
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey[400]!),
                    ),
                    enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black54),
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.blueAccent,
                        width: 2,
                      ),
                    ),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  validator: (value) => value == null || value.isEmpty
                      ? 'Please enter reference number'
                      : null,
                ),
              ),
            ),
    ];
  }

  Widget _buildCancelButton(
    BuildContext context,
    PaymentDialogProvider provider,
  ) {
    return OutlinedButton(
      onPressed: provider.isSubmitting
          ? null
          : () {
              provider.resetFields();
              Navigator.of(context).pop();
            },
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Colors.blue),
        foregroundColor: Colors.blue,
        minimumSize: const Size(double.infinity, 45),
      ),
      child: const Text('Cancel'),
    );
  }

  Widget _buildConfirmButton(
    BuildContext context,
    PaymentDialogProvider provider,
  ) {
    return SizedBox(
      width: double.infinity,
      height: 48,
      child: ElevatedButton(
        onPressed: provider.isSubmitting
            ? null
            : () async {
                if (!provider.formKey.currentState!.validate()) return;

                final bool? shouldConfirm = await showDialog<bool>(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => AlertDialog(
                    backgroundColor: Colors.white,
                    title: const Text(
                      'Confirm Payment',
                      textAlign: TextAlign.center,
                    ),
                    content: Text(
                      'Are you sure you want to proceed with the payment of '
                      '${provider.getAmount().toStringAsFixed(2)}?',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.black),
                    ),
                    actionsPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    actions: [
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(
                                  color: Colors.blueAccent,
                                ),
                                foregroundColor: Colors.blueAccent,
                              ),
                              child: const Text('Cancel'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blueAccent,
                                foregroundColor: Colors.white,
                              ),
                              child: const Text('Confirm'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );

                if (shouldConfirm != true) return;

                // Show full screen loader
                provider.setSubmitting(true);

                try {
                  final Map<String, dynamic> transactionDetails = {};

                  if (provider.selectedPaymentMode == 'Bank') {
                    transactionDetails.addAll({
                      'bankName': provider.selectedBankName,
                      if (provider.selectedBankPaymentMethod == 'neft')
                        'neftNo': provider.transactionController.text,
                      if (provider.selectedBankPaymentMethod == 'rtgs')
                        'rtgsNo': provider.transactionController.text,
                      if (provider.selectedBankPaymentMethod == 'imps')
                        'impsNo': provider.transactionController.text,
                      if (provider.selectedBankPaymentMethod == 'upi')
                        'upi': provider.transactionController.text,
                    });
                  } else {
                    transactionDetails.addAll({
                      if (provider.selectedCashType == 'petty_cash')
                        'pettyCashAmount': provider.getAmount(),
                      if (provider.selectedCashType == 'ho_cash')
                        'hoCash': provider.getAmount(),
                    });
                  }

                  final backendPaymentMethod =
                      provider.selectedPaymentMode == 'Bank'
                      ? provider.selectedBankPaymentMethod
                      : provider.selectedCashType;

                  await onPaymentConfirmed(
                    provider.selectedPaymentType,
                    provider.getAmount(),
                    provider.selectedPaymentMode,
                    backendPaymentMethod,
                    transactionDetails,
                  );

                  provider.resetFields();

                  if (context.mounted) {
                    Navigator.of(context).pop(); // Close the dialog
                  }
                } finally {
                  provider.setSubmitting(false);
                }
              },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25),
          ),
        ),
        child: Center(
          child: Text(
            isBulkPayment ? 'Confirm Bulk Payment' : 'Confirm Payment',
            textAlign: TextAlign.center,
            softWrap: true,
            maxLines: 2,
            overflow: TextOverflow.visible,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ),
      ),
    );
  }
}
